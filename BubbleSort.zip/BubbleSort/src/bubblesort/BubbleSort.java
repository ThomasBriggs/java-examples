/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bubblesort;

import java.util.Arrays;

/**
 *
 * @author thomasbriggs
 */
public class BubbleSort {
    
    public static int[] bubbleSort(int[] sorted){
        int temp;
        for (int i = 0; i < sorted.length-1; i++){
            for (int j = 0; j < sorted.length-1-i; j++){
                if (sorted[j] > sorted[j+1]){
                    temp = sorted[j];
                    sorted[j] = sorted[j+1];
                    sorted[j+1] = temp;
                }
            }
        }
        return sorted;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int [] sorted= new int[5];
        int[] sortMe = {5, 3, 6, 7, 2};
        System.out.println("Un Sorted: " + Arrays.toString(sortMe));
        sorted = bubbleSort(sortMe);
        System.out.println("Sorted: " + Arrays.toString(sorted));
        
    }
    
}
