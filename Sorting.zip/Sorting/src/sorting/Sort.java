/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

/**
 *
 * @author thomasbriggs
 */
public class Sort {
        public int[] bubbleSort(int[] sorted, boolean inverse){
        int temp;
        for (int i = 0; i < sorted.length-1; i++){
            for (int j = 0; j < sorted.length-1-i; j++){
                if (inverse){
                    if (sorted[j] < sorted[j+1]){
                        temp = sorted[j];
                        sorted[j] = sorted[j+1];
                        sorted[j+1] = temp;
                    }
                }else{
                    if (sorted[j] > sorted[j+1]){
                        temp = sorted[j];
                        sorted[j] = sorted[j+1];
                        sorted[j+1] = temp;
                    }   
                }
            }
        }
        return sorted;
    }
    
    public int[] bubbleSortV2(int[] sorted){
        int n = sorted.length;
        boolean flag;
        do{
            flag = false;
            for (int i= 0; i < n-1; i++){
                if (sorted[i] > sorted[i+1]){
                    int temp = sorted[i];
                    sorted[i] = sorted[i+1];
                    sorted[i+1] = temp;
                    flag = true;
                }
            }
            n -=1;
        }while(flag == true || n > 1);
        return sorted;
    }
    
    public int[] insertionSort(int[] sorted){
        int n = sorted.length;
        int temp;
        int j;
        for (int i = 0; i < n; i++){
            temp = sorted[i];
            for (j = i - 1;(j >= 0) && (sorted[j]< temp); j--){
                sorted[j+1] = sorted[j];
            }
            sorted[j + 1] = temp;
        }
        return sorted;
    }
}
