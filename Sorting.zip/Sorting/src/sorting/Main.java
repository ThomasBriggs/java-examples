/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author thomasbriggs
 */
public class Main {
    
    static Random rand = new Random();
    
    public static void populateRandom(int[] list, int num){
        for (int i = 0; i < list.length; i++){
            list[i] = rand.nextInt(num);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Sort sort = new Sort();
        int[] sortMe = new int[rand.nextInt(20)];
        populateRandom(sortMe, 50);
        System.out.println("Original: " + Arrays.toString(sortMe));
        System.out.println("Sorted: " + Arrays.toString(sort.bubbleSort(sortMe, true)));
    }
    
}
